<section class="section-instagram">
    <div class="container-instagram">
        <h2 class="section-title"><?php echo get_field('follow_title'); ?></h2>
        <?php echo do_shortcode('[instagram-feed]'); ?>
    </div>
</section>