<div class="section-booking">

    <?php echo do_shortcode('[booking]'); ?>

</div>