<section class="section-home-banner" style="background-image:url('<?php echo get_field('banner_image')['url']; ?>');">
    <div class="wrap">
        <div class="heading-wrap">
            <h1>
                <span><?php echo get_field('header_line_1'); ?></span>
                <span><?php echo get_field('header_line_2'); ?></span>
            </h1>
        </div>
    </div>
    <div class="scroll">
        <span>Scroll</span>
    </div>
</section>