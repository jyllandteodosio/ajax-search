<div class="two-thirds first">
    <div class="content-contact">

        <?php echo get_Field('contact_form'); ?>
        <p class="inquiry-form"><a href="<?php echo get_field('leasing_inquiry_form'); ?>" target="_blank"><?php echo get_field('file_icon'); ?><?php echo get_field('file_title'); ?></a></p>

    </div>
</div>