<section class="inner-banner" style="background-image:url('<?php echo get_the_post_thumbnail_url(14); ?>');">
    <div class="wrap">
        <h1 class="entry-title" itemprop="headline"><?php echo post_type_archive_title(); ?></h1>
    </div>
</section>