jQuery(function($){
    
    var pitchswiper = new Swiper('.pitch-image', {
      pagination: {
        el: '.swiper-pagination',
        clickable: true
      },
    });
    
    var pitchcontent = new Swiper('.pitch-content', {
    });
    
    pitchswiper.controller.control = pitchcontent;
    pitchcontent.controller.control = pitchswiper;
    
});